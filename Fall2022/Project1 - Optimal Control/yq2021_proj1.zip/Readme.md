# Project 1 - Optimal Control

The decription of the tasks is provided in the Jupyter Notebook "iterative LQR to control a drone.ipynb"

You will need to submit on Brightspace:
1. A report (pdf format only - every other format will be rejected) answering all the questions that do not request code. DO NOT include code in the report.
2. One (or several) Jupyter notebook(s) containing all the code used to answer the questions. The notebook(s) should be runnable as is. The provided files must be runnable on Python 3.8 or above.
